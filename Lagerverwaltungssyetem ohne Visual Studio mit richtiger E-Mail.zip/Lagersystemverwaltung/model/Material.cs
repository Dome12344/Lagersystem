﻿using System;
using System.Collections.Generic;

namespace Auf_WR_Core
{
    public partial class Material
    {
        public int Materialid { get; set; }
        public string? Materialname { get; set; }
        public string? Materialanzahl { get; set; }
        public decimal? Materialpreis { get; set; }
        public double? Materiallänge { get; set; }
    }
}
