﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Lagersystemverwaltung.MainWindow;
namespace Lagersystemverwaltung
{
    /// <summary>
    /// Interaktionslogik für Warenannahme.xaml
    /// </summary>
    public partial class Warenannahme : Window
    {
        private mitarbeiter Mitarbeiter;
        public Warenannahme(mitarbeiter Mitarbeiter)
        {
            InitializeComponent();
            this.Mitarbeiter = Mitarbeiter;
        }

        private void hinzufuegen_Click(object sender, RoutedEventArgs e)
        {
            string Benutzername = Mitarbeiter.Benutzername;
            DateTime date = DateTime.Today;
            if(hinzufuegen.IsEnabled == true )
            {
                try
                {
                    SqlConnection con = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [dbo].[Lager] set Lagerort = @Lagerort,Straße = @Straße, Warennummer = @Warennummer,Materailanzahl = @Materailanzahl Where Materialname = @Materialname", con);
                    cmd.Parameters.AddWithValue("@Materialname", WN.Text);
                    cmd.Parameters.AddWithValue("@Lagerort", LO.Text);
                    cmd.Parameters.AddWithValue("@Straße", straße.Text);
                    cmd.Parameters.AddWithValue("@Warennummer", Convert.ToInt32(Warennummer.Text));
                    cmd.Parameters.AddWithValue("@Materailanzahl", Convert.ToInt32(WA.Text));



                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                catch 
                {

                }
                try
                {
                    SqlConnection con2 = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                    con2.Open();
                    SqlCommand cmd2 = new SqlCommand("Update [dbo].[Material] set Materialanzahl = @Materialanzahl Where Materialname = @Materialname", con2);
                    cmd2.Parameters.AddWithValue("@Materialname", WN.Text);
                    cmd2.Parameters.AddWithValue("@Materialanzahl", Convert.ToInt32(WA.Text));



                    cmd2.ExecuteNonQuery();
                    con2.Close();
                }
                catch 
                {

                }
                try
                {
                    SqlConnection con3 = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                    con3.Open();
                    SqlCommand cmd3 = new SqlCommand("Update [dbo].[Besetllung] set WarenannahmeTage = @WarenannahmeTage Where Materialname = @Materialname", con3);
                    cmd3.Parameters.AddWithValue("@Materialname", WN.Text);
                    cmd3.Parameters.AddWithValue("@WarenannahmeTage", date.ToString("dd,MM,yyyy"));
                }
                catch 
                {

                }

            }

        }

        private void zurueck_Click(object sender, RoutedEventArgs e)
        {
            string Benutzername = Mitarbeiter.Benutzername;
            if (zurueck.IsEnabled == true)
            {
                Auswahlbildschirm auswahlbildschirm = new Auswahlbildschirm(new mitarbeiter(Benutzername));
                this.Close();
                auswahlbildschirm.Show();
            }
        }
    }
}
