﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Lagersystemverwaltung.MainWindow;
namespace Lagersystemverwaltung
{
    /// <summary>
    /// Interaktionslogik für Auswahlbildschirm.xaml
    /// </summary>
    public partial class Auswahlbildschirm : Window
    {
        private mitarbeiter Mitarbeiter;
        
        public Auswahlbildschirm(mitarbeiter Mitarbeiter)
        {
            InitializeComponent();
            this.Mitarbeiter = Mitarbeiter;
        }

        private void ansicht_Click(object sender, RoutedEventArgs e)
        {
            
            if (ansicht.IsEnabled == true)
            {
                Warenansicht warenansicht = new Warenansicht();
                this.Close();
                warenansicht.Show();
            }
        }

        private void bestellen_Click(object sender, RoutedEventArgs e)
        {
            string Benutzername = Mitarbeiter.Benutzername;

            if (bestellen.IsEnabled == true)
            {
                
                Warenbestellen warenbestellen = new Warenbestellen(new mitarbeiter(Benutzername));
                this.Close();
                warenbestellen.Show();
            }
        }

        private void annahme_Click(object sender, RoutedEventArgs e)
        {
            string Benutzername = Mitarbeiter.Benutzername;
            if (annahme.IsEnabled == true)
            {
                Warenannahme warenannahme = new Warenannahme(new mitarbeiter(Benutzername));
                this.Close();
                warenannahme.Show();
            }
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            if(logout.IsEnabled == true) 
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
        }
    }
}
