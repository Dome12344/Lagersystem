﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using static Lagersystemverwaltung.MainWindow;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Lagersystemverwaltung
{
    /// <summary>
    /// Interaktionslogik für Warenbestellen.xaml
    /// </summary>
    public partial class Warenbestellen : Window
    {
        private mitarbeiter Mitarbeiter;
        public Warenbestellen(mitarbeiter Mitarbeiter)
        {
            InitializeComponent();
            this.Mitarbeiter = Mitarbeiter;

        }

        private void bestellen_Click(object sender, RoutedEventArgs e)
        {
            string Benutzername = Mitarbeiter.Benutzername;
            DateTime date = DateTime.Today;
            
            int nummer = 0;
            int anzahl = 0;
            int Mindesbeatnd = 10;
            int Sollbesatnd = 15;
            

            if (bestellen.IsEnabled == true)
            {

                if (Convert.ToInt32(WA.Text) < Mindesbeatnd)
                {
                    MessageBox.Show("Bitten den Mindesbestand von 10 angeben");
                }
                else
                {
                    


                    try
                    {
                        SqlConnection con = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                        con.Open();
                        string add_data_material = "INSERT INTO [dbo].[Material] VALUES (@Materialname, @Materialanzahl,@Materialpreis,@Materiallänge)";
                        SqlCommand cmd = new SqlCommand(add_data_material, con);
                        cmd.Parameters.AddWithValue("@Materialname", WM.Text);
                        cmd.Parameters.AddWithValue("@Materialanzahl", WA.Text);
                        cmd.Parameters.AddWithValue("@Materialpreis", Convert.ToDecimal(PR.Text));
                        cmd.Parameters.AddWithValue("@Materiallänge", Convert.ToSingle(MLM.Text));

                        cmd.ExecuteNonQuery();
                        con.Close();


                    }
                    catch
                    {


                    }
                    try
                    {
                        SqlConnection con2 = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                        con2.Open();
                        string add_data_lager = "INSERT INTO [dbo].[Lager] VALUES (@Lagerort,@Straße,@Warennummer,@Materialname,@Materialanzahl,@Mindestbestand,@Sollbestand)";
                        SqlCommand cmd2 = new SqlCommand(add_data_lager, con2);

                        cmd2.Parameters.AddWithValue("@Lagerort", L.Text);
                        cmd2.Parameters.AddWithValue("@Straße", ZS.Text);
                        cmd2.Parameters.AddWithValue("@Warennummer", nummer);
                        cmd2.Parameters.AddWithValue("@Materialname", WM.Text);
                        cmd2.Parameters.AddWithValue("@Materialanzahl", anzahl);
                        cmd2.Parameters.AddWithValue("@Mindestbestand", Mindesbeatnd);
                        cmd2.Parameters.AddWithValue("@Sollbestand", Sollbesatnd);
                        cmd2.ExecuteNonQuery();
                        con2.Close();

                    }
                    catch
                    {

                    }
                    try
                    {
                        SqlConnection con3 = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                        con3.Open();
                        string add_data_bestllung = "INSERT INTO [dbo].[Bestellung] VALUES (@Lieferrantename,@Materialname,@benutzername,@Bestelldatum,@WarenannahmeTag)";
                        SqlCommand cmd3 = new SqlCommand(add_data_bestllung, con3);
                        cmd3.Parameters.AddWithValue("@Lieferrantenname", BF.Text);
                        cmd3.Parameters.AddWithValue("@Materialname", WM.Text);
                        cmd3.Parameters.AddWithValue("@benutzername", Benutzername);
                        cmd3.Parameters.AddWithValue("@Bestelldatum", date.ToString("dd,MM,yyyy"));
                        cmd3.Parameters.AddWithValue("@WarenannahmeTag", date.ToString("dd,MM,yyyy"));
                        cmd3.ExecuteNonQuery();
                        con3.Close();

                    }
                    catch
                    {

                    }
                    try
                    {
                        SqlConnection con4 = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                        con4.Open();
                        string add_data_lieferrant = "INSERT INTO [dbo].[Lieferrant] VALUES (@Lieferrantename,@Materialpreis,@LieferzeitTage)";
                        SqlCommand cmd4 = new SqlCommand(add_data_lieferrant, con4);
                        cmd4.Parameters.AddWithValue("@Lieferrantename", BF.Text);
                        cmd4.Parameters.AddWithValue("@Materialpreis", Convert.ToDecimal(PR.Text));
                        cmd4.Parameters.AddWithValue("@LieferzeitTage", LZT.Text);
                        cmd4.ExecuteNonQuery();
                        con4.Close();
                    }
                    catch
                    {

                    }
                }
               
            }

        }

        private void zurueck_Click(object sender, RoutedEventArgs e)
        {
            string Benutzername = Mitarbeiter.Benutzername;

            if (zurueck.IsEnabled == true)
            {
                Auswahlbildschirm auswahlbildschirm = new Auswahlbildschirm(new mitarbeiter(Benutzername));
                this.Close();
                auswahlbildschirm.Show();
            }
        }

        

       
    }
}
