﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Auf_WR_Core
{
    public partial class WarenContext : DbContext
    {
        public WarenContext()
        {
        }

        public WarenContext(DbContextOptions<WarenContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Bestellung> Bestellung { get; set; } = null!;
        public virtual DbSet<Lager> Lager { get; set; } = null!;
        public virtual DbSet<Lieferrant> Lieferrant { get; set; } = null!;
        public virtual DbSet<Material> Material { get; set; } = null!;
        public virtual DbSet<Mitarbeiter> Mitarbeiter { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured) 
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=FirmaMetal;Integrated Security=SSPI");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Bestellung>(entity =>
            {
                entity.HasKey(e => e.Bestellungsid);

                entity.Property(e => e.Benutzername)
                    .HasMaxLength(50)
                    .HasColumnName("benutzername");

                entity.Property(e => e.Bestelldatum).HasColumnType("date");

                entity.Property(e => e.Lieferrantename).HasMaxLength(50);

                entity.Property(e => e.Materialname).HasMaxLength(50);

                entity.Property(e => e.WarenannahmeTag).HasColumnType("date");
            });

            modelBuilder.Entity<Lager>(entity =>
            {
                entity.Property(e => e.Lagerort).HasMaxLength(50);

                entity.Property(e => e.Materialname).HasMaxLength(50);

                entity.Property(e => e.Straße).HasMaxLength(50);
            });

            modelBuilder.Entity<Lieferrant>(entity =>
            {
                entity.HasKey(e => e.Lieferid);

                entity.Property(e => e.Lieferrantename).HasMaxLength(50);

                entity.Property(e => e.Materialpreis).HasColumnType("decimal(18, 0)");
            });

            modelBuilder.Entity<Material>(entity =>
            {
                entity.Property(e => e.Materialanzahl).HasMaxLength(50);

                entity.Property(e => e.Materialname).HasMaxLength(50);

                entity.Property(e => e.Materialpreis).HasColumnType("decimal(18, 0)");
            });

            modelBuilder.Entity<Mitarbeiter>(entity =>
            {
                entity.ToTable("mitarbeiter");

                entity.Property(e => e.Benutzername)
                    .HasMaxLength(50)
                    .HasColumnName("benutzername");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .HasColumnName("email");

                entity.Property(e => e.Mitarbeiternummer)
                    .HasMaxLength(50)
                    .HasColumnName("mitarbeiternummer");

                entity.Property(e => e.Nachname)
                    .HasMaxLength(50)
                    .HasColumnName("nachname");

                entity.Property(e => e.Passwortcode)
                    .HasMaxLength(50)
                    .HasColumnName("passwortcode");

                entity.Property(e => e.Telefonnummer)
                    .HasMaxLength(50)
                    .HasColumnName("telefonnummer");

                entity.Property(e => e.Vorname)
                    .HasMaxLength(50)
                    .HasColumnName("vorname");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
