﻿using System;
using System.Collections.Generic;

namespace Auf_WR_Core
{
    public partial class Mitarbeiter
    {
        public int Id { get; set; }
        public string? Benutzername { get; set; }
        public string? Passwortcode { get; set; }
        public string? Vorname { get; set; }
        public string? Nachname { get; set; }
        public string? Mitarbeiternummer { get; set; }
        public string? Email { get; set; }
        public string? Telefonnummer { get; set; }
    }
}
