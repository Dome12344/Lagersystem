﻿using Auf_WR_Core;
using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Windows;
using System.Windows.Data;



namespace Lagersystemverwaltung
{
    /// <summary>
    /// Interaktionslogik für Warenansicht.xaml
    /// </summary>
    public partial class Warenansicht : Window
    {

        private WarenContext _context = new WarenContext();

        private ListCollectionView DisplayView;
        
        public Warenansicht()
        {
            InitializeComponent();


            DataContext =
                DisplayView = new ListCollectionView(_context.Lager.ToList());
            DataContext = DisplayView;

        }

        private void save_Click(object sender, RoutedEventArgs e)
        {

            _context.SaveChanges();
        }

        private void suchen_Click(object sender, RoutedEventArgs e)
        {
            string searchStr = LO.Text.ToLower();


            DisplayView.Filter = null;

            var list = DisplayView.Cast<Lager>();

            Lager n = list.FirstOrDefault(x => x.Materailanzahl.ToString().Contains(searchStr));



            DisplayView.MoveCurrentTo(n);
        }

        private void filter_Click(object sender, RoutedEventArgs e)
        {
            string filter = LO.Text.ToLower();

            DisplayView.Filter = x => ((Lager)x).Materailanzahl.ToString().Contains(filter);
        }

        private void zurueck_Click(object sender, RoutedEventArgs e)
        {

            if (zurueck.IsEnabled == true)
            {
                MainWindow mainWindow = new MainWindow();
                this.Close();
                mainWindow.Show();
            }
        }
    }
}
