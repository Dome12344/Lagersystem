﻿using System;
using System.Collections.Generic;

namespace Auf_WR_Core
{
    public partial class Lager
    {
        public int Lagerid { get; set; }
        public string? Lagerort { get; set; }
        public string? Straße { get; set; }
        public int? Warennummer { get; set; }
        public string? Materialname { get; set; }
        public int? Materailanzahl { get; set; }
        public int? Mindestbestand { get; set; }
        public int? Sollbestand { get; set; }
    }
}
