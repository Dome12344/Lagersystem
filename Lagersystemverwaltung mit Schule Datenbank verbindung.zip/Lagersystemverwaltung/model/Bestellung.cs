﻿using System;
using System.Collections.Generic;

namespace Auf_WR_Core
{
    public partial class Bestellung
    {
        public int Bestellungsid { get; set; }
        public string? Lieferrantename { get; set; }
        public string? Materialname { get; set; }
        public string? Benutzername { get; set; }
        public DateTime? Bestelldatum { get; set; }
        public DateTime? WarenannahmeTag { get; set; }
    }
}
