﻿using System;
using System.Collections.Generic;

namespace Auf_WR_Core
{
    public partial class Lieferrant
    {
        public int Lieferid { get; set; }
        public string? Lieferrantename { get; set; }
        public decimal? Materialpreis { get; set; }
        public int? LieferzeitTage { get; set; }
    }
}
