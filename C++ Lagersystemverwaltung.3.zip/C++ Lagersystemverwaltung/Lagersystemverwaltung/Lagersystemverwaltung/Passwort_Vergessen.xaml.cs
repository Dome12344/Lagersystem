﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lagersystemverwaltung
{
    /// <summary>
    /// Interaktionslogik für Passwort_Vergessen.xaml
    /// </summary>
    public partial class Passwort_Vergessen : Window
    {
        public Passwort_Vergessen()
        {
            InitializeComponent();
        }

        private void bpn_Click(object sender, RoutedEventArgs e)
        {
            if(bpn.IsEnabled == true)
            { 
                if(PN.Password == BPN.Password)
                {
                    SqlConnection con = new SqlConnection(@"Server=DESKTOP\MYSQLSERVER;Database=FirmaMetal;Integrated Security = True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Update [dbo].[mitarbeiter] set Passwortcode = @passwortcode Where Mitarbeiternummer = @mitarbeiternummer", con);
                    cmd.Parameters.AddWithValue("@mitarbeiternummer", MN.Text);
                    cmd.Parameters.AddWithValue("@passwortcode", BPN.Password);
                    
                    
                    
                    
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MN.Text = "";
                    BPN.Password = "";
                    Auswahlbildschirm auswahlbildschirm = new Auswahlbildschirm();
                    auswahlbildschirm.Show();
                    this.Close();

                }
            
               
            }
        }

        private void break_Click(object sender, RoutedEventArgs e)
        {
            if(zurueck.IsEnabled == true) 
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }

        }
    }
}
