﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lagersystemverwaltung
{
    /// <summary>
    /// Interaktionslogik für Warenansicht.xaml
    /// </summary>
    public partial class Warenansicht : Window
    {
        public Warenansicht()
        {
            InitializeComponent();
        }

        private void save_Click(object sender, RoutedEventArgs e)
        {

        }

        private void suchen_Click(object sender, RoutedEventArgs e)
        {

        }

        private void filter_Click(object sender, RoutedEventArgs e)
        {

        }

        private void zurueck_Click(object sender, RoutedEventArgs e)
        {
            //if (zurueck.IsEnabled == true)
            //{
            //    Auswahlbildschirm auswahlbildschirm = new Auswahlbildschirm();
            //    this.Close();
            //    auswahlbildschirm.Show();
            //}
        }
    }
}
